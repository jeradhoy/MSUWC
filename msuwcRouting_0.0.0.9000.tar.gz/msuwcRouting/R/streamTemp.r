###################################
#Functions for routing LPF-GUESS Runoff
#
#Created by Jerad Hoy
#Date Created: 7/7/2015
#Date Last Modified:
#
#Sourced into streamNetwork.r file to do actual routing
#

#' Stream Temperature
#'
#' Routes runoff through a stream network using various physical relationships.
#'
#' @param edges
#' @param catchments
#' @param Rsurf
#' @param Rsub
#' @param spinUpCycles
#' @param spinUpYears
#' @param debugMode
#' @param by
#' @param widthCoeffs
#' @param manningN
#' @param slopeMin
#' @param aCoeffCoeff
#' @param outputExtraVars
#'
#' @return List of matrices of routing variable timeseries.
#'
#' @examples
#' flow <- RouteWater(edges=edgesInBounds, catchments=catchmentsInBounds, Rsurf=surfaceRunoff,  Rsub=subsurfRunoff, spinUpCycles=gwSpinUpCycles, spinUpYears=spinUpYears, debugMode=F, by=timeStep, widthCoeffs=streamWidthCoeffs, manningN=manningN, slopeMin=slopeMin, aCoeffCoeff=aCoeffCoeff)
#'
#' @name StreamTemp
#' @export

# Routes surface and subsurface water through river network
StreamTemp <- function(edges, catchments, RsurfSnow, RsurfNoSnow, Tair, simFlow, defaults=setupList, by="month", outputExtraVars=T, debugMode=T, historical=T){
    
	edges <- as.data.frame(edges@data)
    edges <- AssignContribArea(edges, catchments)

    # Order edges by Shreve order so calculation is in right order
    edges <- edges[order(edges[, defaults$edgeOrderField]),]

	edges$LengthKM <- edges[, defaults$edgeLengthField] * 120

	edges[,defaults$edgeIdField] <- as.character(edges[, defaults$edgeIdField])

	RsurfSnow <- RsurfSnow[,match(edges[, defaults$edgeIdField], colnames(RsurfSnow))]

	RsurfNoSnow <- RsurfNoSnow[,match(edges[, defaults$edgeIdField], colnames(RsurfNoSnow))]

	annualTmean <- rep(getAnnualTmean(Tair), times=1, each=ifelse(by == "month", 12, 365))
	Tair <- Tair[,match(edges[, defaults$edgeIdField], colnames(Tair))]

	simFlow <- lapply(simFlow, function(x) x[,match(edges[, defaults$edgeIdField], colnames(x))])	
	if(historical) simFlow <- lapply(simFlow, function(x) x[1:396,])

	#########
	## Need to subset all of simflow for faster computation
	#####


    # Set the timeLength to avoid re-executing nrow function
    timeLength <- nrow(RsurfSnow) 
    # Create seed matrix to use for storing data in results


    seedMatrix <- matrix(0, nrow=timeLength, ncol=ncol(RsurfSnow),
        dimnames=list(rownames(RsurfSnow), edges[, defaults$edgeIdField]))



    results <- list(
        Twater = seedMatrix,
        TwaterLocal = seedMatrix,
        TwaterInitial = seedMatrix
    )

    rm(seedMatrix)

	Tsnow <- .1

    if(by == "day"){
		# Set the velocity conversion factor for a daily timestep
		vConvFactor <- 60*60*24/1000
	}

	# Set days in month to use for monthly-timestep velocity conversion factor
	daysInMonth <- c(31,28,31,30,31,30,31,31,30,31,30, 31)

    
    print("About to Run")
	spinUpCycles <- 0
	cycleCount <- 0
			
	if(historical == T){
		stepsToLoop <- 396
	} else {
		stepsToLoop <- nrow(RsurfSnow)
	}
	try(
	for(timeStep in 1:stepsToLoop){
		#print(paste("Cycle:", cycleCount, "Timestep:",  timeStep))
		# Start time to use for fucntion time-estimates
		start <- Sys.time()

		# Loop through edges in river network
		for(i in 1:nrow(edges)){
			#print(i)

			# Set hydroID of edges so don have to keep subsetting
			hydroID <- edges[i, defaults$edgeIdField]
			ord <- edges[i, defaults$edgeOrderField] 

			if(by == "month"){
				 # Set velocity conversion factor based on month of timestep
				#convert from m/s to km/month
				 vConvFactor <- 60*60*24*daysInMonth[as.numeric(format(zoo::as.yearmon(rownames(RsurfSnow[timeStep,])), "%m"))]/1000
			}

			
			v1 <- simFlow$v[timeStep, hydroID] ##m/s ##NEED to convert to m/month if month
			v <- v1*vConvFactor

			len <- edges$LengthKM[i]
			
			
			qSnow <- RsurfSnow[timeStep, hydroID]
			qNoSnow <- RsurfNoSnow[timeStep, hydroID]

			qGw <- simFlow$qSub[timeStep, hydroID]
			qOut <- simFlow$qOut[timeStep, hydroID]
			qIn <- simFlow$qIn[timeStep, hydroID]

			Tgw <- annualTmean[timeStep]+1.5 ###often 1-2*C higher than mean annual air temperature of a region, annual time series

			if(timeStep > 1){
				TwaterOld <- results$Twater[timeStep - 1, hydroID] 
				sRiv <- simFlow$sRiv[timeStep - 1, hydroID]
			} else {
				TwaterOld <- 0
				sRiv <- 0
			}

			TairLocal <- Tair[timeStep, hydroID]

			if(by == "month"){
				TairLag <- TairLocal
				lamda <- 1
			} else {
				print(" by == day ??")
				TairLag #### Need to make some sort of lag for daily air temp
				lamda ####
			}

			##
			## NEED TO CHECK that qOut - qLocal equals qIn
			##

			qLocal <- (qSnow+qGw+qNoSnow)
			print(qLocal)
			#print(qOut - qIn)
			#print(qLocal)




			# temperature of the water before effects of air and upstream temperature
			if(qLocal > 0){
				TwaterLocal <- ((Tsnow*qSnow)+(Tgw*qGw)+(lamda*TairLag)*qNoSnow)/qLocal
			} else {
				TwaterLocal <- 0
			}
			

			#print("Caculated TwaterLocal")




			print(ord)
			if(ord == 1){

				#TwaterInitial <- TwaterLocal
				TwaterUpstream <- 0

			} else {
				#May need to calculated weighted temperatures
				qInUpstream <- simFlow$qOut[timeStep, edges[edges[, defaults$edgeNextDownField] == edges[i, defaults$edgeIdField], defaults$edgeIdField]]

				TwaterUpstream <- results$Twater[timeStep, edges[edges[, defaults$edgeNextDownField] == edges[i, defaults$edgeIdField], defaults$edgeIdField]]

				#print(TwaterIn)
				print(qInUpstream)
				print(TwaterUpstream)

				if(any(sapply(c(qInUpstream, TwaterUpstream), function(x) is.nan(x)))){
					stop()
				}
				
				TwaterUpstream <- sum(qInUpstream*TwaterUpstream)/sum(TwaterUpstream)
				#TwaterInitial <- (TwaterUpstream(qOut - qLocal) + TwaterLocal*qLocal)/qOut
			}




			if(len/v < 1){

				rSqSubTT <- (1 - len/(2*v)) ##
				sRivTT <- len/v

				if(ord > 1){

					###Get dimensionless factor, multiply times time to get TT?
					qInTT  <- (1 - len/v) ##gives fraction of timestep
				} else {
					qInTT <- 0
				}

			} else {
				print("len/v > 1????")
				stop()
				qInTT 
				rSqSubTT
				sRivTT
			}

			#reachTravelTime <- simFlow$TT[timeStep, hydroID] ## TT (hour) travel time of water through the subbasain 

			## Need to modify k
			K <- .5##K (1/h) is a bulk coefficient of heat transfer and ranges from 0 to 1

			#TairLocal = 5

			if(TairLocal > 0){
				TwaterLocalWarmed <- TwaterLocal + (TairLocal - TwaterLocal)*K*rSqSubTT
				TwaterQin <- TwaterUpstream + (TairLocal - TwaterUpstream)*K*qInTT
		
				TwaterSriv <- TwaterOld + (TairLocal - TwaterOld)*K*sRivTT


				####OLD Twater code
				#Twater <- TwaterInitial + (TairLocal - TwaterInitial) * K * reachTravelTime
			} else {
				epsilon <- 2.5 ####Set to 2.5*C before sensitivity testing

				TwaterLocalWarmed <- TwaterLocal + ((TairLocal + epsilon) - TwaterLocal)*K*rSqSubTT
				TwaterQin <- TwaterUpstream + ((TairLocal + epsilon) - TwaterUpstream)*K*qInTT
		
				TwaterSriv <- TwaterOld + ((TairLocal + epsilon) - TwaterOld)*K*sRivTT
				###Twater <- TwaterInitial + ((TairLocal + epsilon) - TwaterInitial) * K * (reachTravelTime)
			}

			if(qIn == 0 && qLocal == 0 && sRiv == 0){
				Twater <- 0
			} else {
				Twater <- (TwaterQin*qIn + TwaterLocalWarmed*qLocal + TwaterSriv*sRiv)/(qIn+qLocal+sRiv)
			}


			# Store values in results list
			results$Twater[timeStep, hydroID] <- Twater


			if(debugMode == T){
				try(c(
					print(paste("Day:",timeStep, "Edge:", hydroID, "Order:", ord)),

					print(paste0("v1 = ", v1)),
					print(paste0("v = ", v)),
					print(paste0("len = ", len)),
					print(paste0("len/v = ", len/v)),
					print(paste0("lamda = ", lamda)),

					print(paste0("qSnow = ", qSnow)),
					print(paste0("qGw = ", qGw)),
					print(paste0("qNoSnow = ", qNoSnow)),


					print(paste0("Tsnow = ", Tsnow)),
					print(paste0("TairLocal = ", TairLocal)),
					print(paste0("Tgw = ", Tgw)),
					print(paste0("TairLag = ", TairLag)),
					print(paste0("TwaterLocal = ", TwaterLocal)),
					print(paste0("TwaterOld = ", TwaterOld)),
					print(paste0("TwaterUpstream = ", TwaterUpstream)),

					print(paste0("qIn = ", qIn)),
					print(paste0("qLocal = ", qLocal)),
					print(paste0("sRiv = ", sRiv)),
					print(paste0("TwaterQin = ", TwaterQin)),
					print(paste0("TwaterLocalWarmed = ", TwaterLocalWarmed)),
					print(paste0("TwaterSriv = ", TwaterSriv)),

					print(paste("Twater = ", Twater))
				))
			}
			if(is.nan(Twater)){
				stop("NaN found!!")
			}

			if(outputExtraVars){
				results$TwaterLocal[timeStep, hydroID] <- TwaterLocal
			}
			


		}



		if(cycleCount == 0 & timeStep == 10){

		print(paste("ETA:", 
				#round((Sys.time()-start) * (timeLength*(spinUpCycles1+1)length((timeStep+1):timeLength)/10*(spinUpCycles+1), 2), 
				round((Sys.time()-start) * (timeLength + spinUpCycles*spinUpYears*ifelse(by == "day",365, 12))/10), 
				"seconds or", 
				#round((Sys.time()-start)*length((timeStep+1):timeLength)/10/60*(spinUpCycles+1), 2), 
				round((Sys.time()-start) * (timeLength + spinUpCycles*spinUpYears*ifelse(by == "day",365, 12))/10/60), 
				"minutes. Will finish at", 
				(Sys.time()-start)*length((timeStep+1):timeLength)/10*(spinUpCycles+1)+Sys.time()
			))
		}
    })
    return(results)
}


getAnnualTmean <- function(tMeanFrame){
	results <- c()
    for(i in 1:33){
		#print(1:12+12*(i-1))
		results <- c(results, mean(colMeans(tMeanCatch[1:12+12*(i-1),])))
	}
	return(results)
}
